#!/bin/bash

# load config
source config.sh

# download proot
curl -LO https://proot.gitlab.io/proot/bin/proot
chmod +x ./proot

# download iso and decompress the squashfs from the iso
wget $ISOLINK
7z e $ISONAME "casper/filesystem.squashfs"
unsquashfs -d squashfs filesystem.squashfs

# proot inside the squashfs to upgrade and apply patches
mv rootfs_patches.sh squashfs/rootfs_patches.sh
chmod +x squashfs/rootfs_patches.sh
./proot -S squashfs /bin/bash /rootfs_patches.sh

# make the startwm script executable
chmod +x /defaults/startwm.sh

# move the patched root fs to the root
cp -r squashfs/* /
rm -rf squashfs $ISONAME filesystem.squashfs