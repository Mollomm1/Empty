#!/bin/bash

export ISOLINK="https://mirrors.cicku.me/linuxmint/iso/debian/lmde-6-cinnamon-64bit.iso" # iso link
export ISONAME="lmde-6-cinnamon-64bit.iso"
export ISOTYPE="squashfs" # actually only support squashfs based isos