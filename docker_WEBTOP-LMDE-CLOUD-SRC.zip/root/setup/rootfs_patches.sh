echo "**** update and upgrade all packages ****"
echo "Acquire::Check-Valid-Until false;" | tee -a /etc/apt/apt.conf.d/10-nocheckvalid 
apt update
apt upgrade -y
rm -rf \
  /config/.cache \
  /var/lib/apt/lists/* \
  /var/tmp/* \
  /tmp/*
apt update
apt upgrade -y
apt remove -y blueman boot-repair calamares gnome-disk-utility gparted
rm /usr/bin/pkexec
ln -s /usr/bin/sudo /usr/bin/pkexec
rm -rf \
  /config/.cache \
  /var/lib/apt/lists/* \
  /var/tmp/* \
  /tmp/*