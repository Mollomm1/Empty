#!/bin/bash
setterm blank 0
setterm powerdown 0
export XDG_SESSION_TYPE=x11
export DESKTOP_SESSION=cinnamon
export GNOME_SHELL_SESSION_MODE=cinnamon
export XDG_CURRENT_DESKTOP=cinnamon

sudo service dbus start
export $(dbus-launch)

if [ ! -f "/config/.firstsetup" ]; then
    sudo rm -rf /config/.cache # fix caching
    mkdir -p /config/.config/gtk-3.0/ /config/.config/gtk-4.0/
    echo -e "[Settings]\ngtk-application-prefer-dark-theme=1" > ~/.config/gtk-4.0/settings.ini # fix dark theme
    echo -e "[Settings]\ngtk-application-prefer-dark-theme=1" > ~/.config/gtk-3.0/settings.ini # fix dark theme
    mkdir /config/Desktop
    mv /defaults/README_EN.html /config/Desktop/README_EN.html
    mv /defaults/LMDE_CE_src.zip /config/Desktop/LMDE_CE_src.zip
    touch /config/.firstsetup
fi

alias pkexec="sudo"

cinnamon-session-cinnamon2d > /dev/null 2>&1
